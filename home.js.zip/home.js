
function getServerData(url, success){
    $.ajax({
        dataType: "json",
        url: url
    }).done(success);
}

//using the ajax function to implemente GET
function getServerGet(url, success){
    $.ajax({
        url : url,  //name of the file php
        type : 'GET',  //type of the HTTP requet
        dataType : 'html'  //data type to receive
    }).done(success);
}

//using the ajax function to implemente POST
function getServerPost(url, success){
    $.ajax({
        url : url,
        type : 'POST',
        dataType : 'html'
    }).done(success);
}

//using the ajax function to implemente PUT
function getServerPut(url, success){
    $.ajax({
        url : url,
        type : 'PUT',
        dataType : 'html'
    }).done(success);
}

//using the ajax function to implemente DELETE
function getServerDelete(url, success){
    $.ajax({
        url : url,
        type : 'DELETE',
        dataType : 'html'
    }).done(success);
}

function callDone(result){
	var templateExample = _.template($('#templateExample').html());

	var html = templateExample({
		"attribute":JSON.stringify(result)
	});

	$("#result").append(html);
}

$(function(){
	$("#button").click(function(){
		getServerData("ws/example/aircraft",callDone);
	});
});